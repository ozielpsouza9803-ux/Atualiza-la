import { createClient } from '@supabase/supabase-js';

// Supabase configuration for Lar Esperança project (utrpckrchcbqgzbhvlzy)
const supabaseUrl = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) || 'https://utrpckrchcbqgzbhvlzy.supabase.co';
const supabaseAnonKey = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) || 'sb_secret_DBh3f-vNLTWLNWU__CV5YA_9TjfKL71';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function testSupabaseConnection() {
  try {
    const { error } = await supabase.from('kids').select('id').limit(1);
    if (error) {
      console.warn('Supabase connection note:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase connection error:', err);
    return false;
  }
}

export interface SupabaseDataResult {
  kids: any[];
  gifts: any[];
  siteSettings: any | null;
  gallery: any[];
}

export async function fetchAllSupabaseData(): Promise<SupabaseDataResult | null> {
  try {
    const [kidsRes, giftsRes, settingsRes, galleryRes] = await Promise.all([
      supabase.from('kids').select('*').order('created_at', { ascending: true }),
      supabase.from('gifts').select('*'),
      supabase.from('site_settings').select('*').limit(1),
      supabase.from('gallery').select('*').order('sort_order', { ascending: true })
    ]);

    return {
      kids: kidsRes.data || [],
      gifts: giftsRes.data || [],
      siteSettings: settingsRes.data?.[0] || null,
      gallery: galleryRes.data || []
    };
  } catch (err) {
    console.error('Error fetching data from Supabase:', err);
    return null;
  }
}

